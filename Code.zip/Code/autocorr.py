import numpy as np
import matplotlib.pyplot as plt
import spicy as sp

def read_output_file(filename):
    with open(filename, 'r') as file:
        lines = file.readlines()

    # Determine the number of time steps (T) and the number of elements (NTOT)
    T = len(lines)
    NTOT = len(lines[0].split())

    # Initialize the matrix
    matrix = np.zeros((T, NTOT), dtype=int)

    # Fill the matrix with data from the file
    for i, line in enumerate(lines):
        matrix[i, :] = np.array(line.split(), dtype=float)

    return matrix,T,NTOT

def autocorrelation(x, lag=1):
    x = np.array(x)
    return np.corrcoef(x[:-lag], x[lag:])[0, 1]

def personcorr_aprox1(h,psi,mu):
    x = ((psi+(1-mu*(1+psi))**h)/(1+psi)*psi-psi**2)/(psi-psi**2)
    return x
def personcorr_aprox2(h,psi,mu):
    x = (((psi+((1-mu)+mu**2*psi-mu*psi)**h)/(1+psi))*psi-psi**2)/(psi-psi**2)
    return x
if __name__ == "__main__":


    filename = 'output.txt'
    matrix,T,NTOT = read_output_file(filename)
    SK = 1000
    mu=0.5
    h = np.linspace(0,14,15)
    # Compute ACF for multiple lags and average for the first 1000 particles
    corr_val = np.zeros(16)
    psi=1/1000
    for i in range(15):
        for j in range(1000):
            k = np.corrcoef(matrix[SK:T-i, j],matrix[SK+i:T, j])
            corr_val[i] += k[1,0]
        corr_val[i] = corr_val[i] / 1000

    print(corr_val)
    plt.plot(corr_val,label='sim. Corr.')
    plt.plot(h,personcorr_aprox1(h,psi,mu),color='black',label='Theo. Corr.')
    plt.ylabel('Autocorr')
    plt.xlabel('lag')
    plt.legend(loc='upper right')
    plt.show()
    
    # Compute ACF for multiple lags and average for the first 1000 particles
    corr_val = np.zeros(16)
    g=0
    psi=0.01/(20*1000)
    for i in range(15):
        for j in range(1000,2000):
            k = np.corrcoef(matrix[SK:T-i, j],matrix[SK+i:T, j])
            if not np.isnan(k[1,0]):
                corr_val[i] += k[1,0]
                g+=1
        corr_val[i] = corr_val[i] / g

    print(corr_val)
    plt.plot(corr_val,label='sim. Corr.')
    plt.plot(h,personcorr_aprox2(h,psi,mu),color='black',label='Theo. Corr.')
    plt.ylabel('Autocorr')
    plt.xlabel('lag')
    plt.legend(loc='upper right')
    plt.show()