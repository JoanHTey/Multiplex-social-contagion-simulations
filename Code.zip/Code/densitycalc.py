import numpy as np

def read_output_file(file_path):
    with open(file_path, 'r') as file:
        data = file.readlines()
    
    # Assuming the data is space-separated and numerical
    data_array = np.array([list(map(float, line.split())) for line in data])
    return data_array

def extract_density_vs_time(data_array):
    # Assuming the first column is time and the rest are densities for each layer
    NTOT,TIME = data_array.shape()
    TOTden = np.mean(data_array[:,1:NTOT],axis=1) 
    L1den = np.mean(data_array[:,1:NTOT//2],axis=1)
    L2den = np.mean(data_array[:,NTOT//2:NTOT],axis=1)
    return TOTden, L1den, L2den

def extract_susceptibility(data_array,TOTden,L1den,L2den):
    # Assuming susceptibility is calculated or provided in the data
    # Placeholder for actual susceptibility extraction logic
    susceptibility = np.random.random(data_array.shape[1] - 1)  # Replace with actual logic
    return susceptibility

def main():
    file_path = 'output.txt'
    data_array = read_output_file(file_path)
    
    TOTden,L1den,L2den = extract_density_vs_time(data_array)
    susceptibility = extract_susceptibility(data_array)
    
    # Print or save the extracted data
    print("Time:", time)
    print("Densities:", densities)
    print("Susceptibility:", susceptibility)

if __name__ == "__main__":
    main() 